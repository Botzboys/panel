const { createCanvas, loadImage, registerFont } = require('canvas');
const path = require('path');

// Function to chunk text into lines
function chunkText(text, maxCharacters) {
   const words = text.split(' ');
   let lines = [''];
   let currentLine = 0;

   for (const word of words) {
      if (lines[currentLine].length + word.length <= maxCharacters) {
         lines[currentLine] += word + ' ';
      } else {
         lines[++currentLine] = word + ' ';
      }
   }

   return lines.map(line => line.trim());
}

exports.run = {
   usage: ['paper3'],
   use: 'judul|isi teks',
   category: 'text maker',
   async: async (m, { client, text, Func, isPrefix, command }) => {
      try {
         if (!text) return client.reply(m.chat, Func.example(isPrefix, command, 'judul|isi dokumen'), m);

         client.sendReact(m.chat, '🕘', m.key);

         const [title, docText] = text.split('|');
         if (!title || !docText) return client.reply(m.chat, Func.example(isPrefix, command, 'judul|isi dokumen'), m);
         if (title.length > 5 || docText.length > 1600) return client.reply(m.chat, '🚩 Judul max 5 character & 1600 Character', m);

         // Load fonts
         registerFont(path.join('media/fonts/Neuton-SC-Bold.ttf'), { family: 'TitleFont' });
         registerFont(path.join('media/fonts/Neuton-Italic.ttf'), { family: 'TextFont' });

         // Load background
         const bg = await loadImage('https://i.ibb.co/FBXgMtR/image.jpg');

         // Create canvas
         const canvas = createCanvas(bg.width, bg.height);
         const ctx = canvas.getContext('2d');

         // Draw background
         ctx.drawImage(bg, 0, 0, bg.width, bg.height);

         // Draw title text
         ctx.font = 'bold 60px "TitleFont"';
         ctx.fillStyle = '#000000'; // Black text color
         ctx.textAlign = 'center';
         // ctx.textBaseline = 'top';
         ctx.fillText(title, bg.width / 2, 85);

         // Draw document text
         const maxCharsPerLine = 55;
         const lines = chunkText(docText, maxCharsPerLine);
         const lineHeight = 25;

         ctx.font = '15px "TextFont"';
         ctx.fillStyle = '#000000'; // Black text color
         ctx.textAlign = 'left';
         ctx.textBaseline = 'top';

         lines.forEach((line, index) => {
            const y = 180 + index * lineHeight;
            ctx.fillText(line, 70, y);
         });

         // Convert canvas to buffer and send as file
         const buffer = canvas.toBuffer('image/jpeg');
         client.sendFile(m.chat, buffer, 'dokumen.jpg', `*✨ Ini kak hasil nya*`, m);
         await Func.delay(1000);
         client.sendReact(m.chat, '✅', m.key);
      } catch (e) {
         console.error(e);
         client.reply(m.chat, Func.texted('bold', `🚩 Can't generate dokumen image.`), m);
         client.sendReact(m.chat, '❌', m.key);
      }
   },
   error: false,
   limit: true,
   cache: true,
   location: __filename
};