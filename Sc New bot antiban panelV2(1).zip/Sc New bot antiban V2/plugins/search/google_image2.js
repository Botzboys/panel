const Scraper = require('images-scraper');

const google = new Scraper({
  puppeteer: {
    headless: true,
    args: ['--no-sandbox'],
  },
});

exports.run = {
   usage: ['google-image2'],
   hidden: ['gimg2'], 
   use: 'query',
   category: 'search',
   async: async (m, { client, text, isPrefix, command, Func }) => {
      try {
         if (!text) return client.reply(m.chat, Func.example(isPrefix, command, 'Banana'), m);

         client.sendReact(m.chat, '🕘', m.key);

         const results = await google.scrape(text, 5);

         if (results.length === 0) {
            return client.reply(m.chat, '❌ No images found for the given query.', m);
         }

         for (const img of results) {
            client.sendFile(m.chat, img.url, 'image.jpg', `*Google Image Search:*\nSource: ${img.source}\nTitle: ${img.title}

${global.footer}`, m);
         }
         Func.delay(1000);
         client.sendReact(m.chat, '✅', m.key); 
      } catch (e) {
         console.error(e);
         client.reply(m.chat, '❌ An error occurred while processing the request.', m);
      }
   },
   error: false,
   limit: true,
   location: __filename
};


