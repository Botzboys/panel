const axios = require('axios');

exports.run = {
   usage: ['wikipedia'],
   hidden: ['wiki'], 
   use: 'lang|query', 
   category: 'search',
   async: async (m, { client, text, Func, isPrefix, command }) => {
      try {
         const [lang, query] = text.split(' ');
         if (!query || !lang) return client.reply(m.chat, Func.example(isPrefix, command, 'id Toronto Raptors'), m);

         client.sendReact(m.chat, '🕒', m.key);

         const apiUrl = `https://${lang}.wikipedia.org/w/api.php?action=query&format=json&list=search&utf8=1&srsearch=${encodeURIComponent(query)}`;

         const response = await axios.get(apiUrl);

         if (response.data && response.data.query && response.data.query.search) {
            const results = response.data.query.search;

            if (results.length > 0) {
               const firstResult = results[0];
               const pageId = firstResult.pageid;

               const pageUrl = `https://${lang}.wikipedia.org/?curid=${pageId}`;
               const cleanSnippet = firstResult.snippet.replace(/<\/?[^>]+(>|$)/g, '');

               client.reply(m.chat, `📚 Wikipedia Results for *${query}*\n\n*Title:* ${firstResult.title}\n*Description:* ${cleanSnippet}\n*Link:* ${pageUrl}\n\n${global.footer}`, m);
               client.sendReact(m.chat, '✅', m.key);
            } else {
               client.reply(m.chat, `🚩 No Wikipedia results found for *${query}* in ${lang.toUpperCase()}`, m);
            }
         } else {
            client.reply(m.chat, `🚩 Failed to fetch Wikipedia results. Please try again later.`, m);
         }
      } catch (error) {
         console.error(error);
         client.reply(m.chat, `🚩 An error occurred while processing the request. Please try again later.`, m);
      }
   },
   error: false,
   limit: true,
   location: __filename
};