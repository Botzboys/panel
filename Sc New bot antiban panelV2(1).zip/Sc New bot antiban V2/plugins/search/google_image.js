const gis = require('g-i-s');

exports.run = {
   usage: ['google-image'],
   hidden: ['gimg'], 
   use: 'query',
   category: 'search',
   async: async (m, { client, text, isPrefix, command, Func }) => {
      try {
         if (!text) return client.reply(m.chat, Func.example(isPrefix, command, 'Kucing'), m);
         client.sendReact(m.chat, '🕘', m.key) 

         gis(text, (error, results) => {
            if (error) {
               console.error(error);
               if (error.response && error.response.status === 403 && error.response.status === 404) {
                  return client.reply(m.chat, '❌ Cannot display images. Try another query.', m);
               } else {
                  return client.reply(m.chat, '❌ Error occurred while fetching images.', m);
               }
            } else {
               const images = results.slice(0, 5);

               if (images.length === 0) {
                  return client.reply(m.chat, '❌ No images found for the given query.', m);
               }

               for (const img of images) {
                  client.sendFile(m.chat, img.url, 'image.jpg', `*Google Image Search:*\n${img.url}\n\nWidth: ${img.width}, Height: ${img.height}

${global.footer}`, m);
               Func.delay(1000);
               client.sendReact(m.chat, '✅', m.key);
               }
            }
         });
      } catch (e) {
         console.error(e);
         client.reply(m.chat, '❌ An error occurred while processing the request.', m);
      }
   },
   error: false,
   limit: true,
   location: __filename
};