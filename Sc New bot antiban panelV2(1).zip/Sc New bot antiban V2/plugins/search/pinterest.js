const { search } = require('pinterest-dl');

exports.run = {
   usage: ['pinterest'],
   use: 'query',
   category: 'search',
   async: async (m, { client, text, isPrefix, command, Func }) => {
      try {
         if (!text) return client.reply(m.chat, Func.example(isPrefix, command, 'kucing'), m);

         client.sendReact(m.chat, '🕒', m.key)
         let old = new Date()
         const data = await search(text);

         if (!data || data.length === 0) {
            return client.reply(m.chat, '❌ No images found for the given query on Pinterest.', m);
         }

         for (let i = 0; i < data.length; i++) {
            const img = data[i];

            if (img) {
               client.sendFile(m.chat, img, 'image.jpg', `Image for : ${text}

🍟 *Fetching* : ${((new Date - old) * 1)} ms

${global.footer}`, m);

               client.sendReact(m.chat, '✅', m.key)

               if (i < data.length - 1) {
                  await new Promise(resolve => setTimeout(resolve, 1000));
               }
            } else {
               console.error('Invalid image data:', img);
            }
         }
      } catch (e) {
         console.error(e);
         client.reply(m.chat, '❌ An error occurred while processing the request.', m);
      }
   },
   error: false,
   limit: true,
   location: __filename
};