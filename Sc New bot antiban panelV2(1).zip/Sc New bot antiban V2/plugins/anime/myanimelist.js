const malScraper = require('mal-scraper');

exports.run = {
  usage: ['search-anime', 'myanimelist'],
  use: 'judul',
  category: 'anime', 
  async: async (m, { text, client, isPrefix, command, Func }) => {
    try {
      if (!text) return client.reply(m.chat, Func.example(isPrefix, command, 'One Piece'), m);

      const name = text;

      client.sendReact(m.chat, '🕘', m.key)

      const data = await malScraper.getInfoFromName(name);

      const synopsis = data.synopsis.replace(/\n\n/g, '\n');

      const characterList = data.characters.map(char => {
        return `○ Name : ${char.name}
○ Role : ${char.role}
○ Seiyuu : ${char.seiyuu.name}
*~~~*`;
      }).join('\n');

      const staffList = data.staff.map(staff => {
        return `○ Staff : ${staff.name}
○ Staff Role : ${staff.role}
*~~~*`;
      }).join('\n');

      const response = `*❒  I N F O - A N I M E*
      
📺 *Judul:* ${data.title}
*______________________*

📝 *Sinopsis:* ${synopsis}
*______________________*

🎭 *Karakter:*
${characterList}
*______________________*

👥 *Staf:*
${staffList}
*______________________*

🔗 *URL:* ${data.url}

${global.footer}`;

      client.sendFile(m.chat, data.picture, 'image.jpg', response, m);
      Func.delay(1500);
      client.sendReact(m.chat, '✅', m.key); 
    } catch (error) {
      console.error(error);
      client.reply(m.chat, 'Terjadi kesalahan saat memproses permintaan.', m);
    }
  },
  limit: true,
  error: false,
};