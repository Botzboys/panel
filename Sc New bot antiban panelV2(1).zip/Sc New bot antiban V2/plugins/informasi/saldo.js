const axios = require('axios');

exports.run = {
   usage: ['saldo'],
   async: async (m, { client, Func }) => {
      try {
         let number = (m.sender).split('@')[0];

         // Dapatkan saldo berdasarkan nomor
         const saldo = await getSaldo(number);

         if (saldo !== null) {
            // Kirim saldo ke pengguna jika ditemukan
            client.reply(m.chat, `❒ *S A L D O  A K U N*

○ Nomor : ${number}
○ Saldo : Rp. ${Func.formatNumber(saldo)}`, m);
         } else {
            // Kirim pesan jika pengguna belum terdaftar
            client.reply(m.chat, 'Pengguna belum terdaftar, Silahkan Sign Up / Login ke Akun', m);
         }
      } catch (e) {
         console.error(e);
         client.reply(m.chat, 'Terjadi kesalahan dalam memproses permintaan. Silakan coba lagi nanti.', m);
      }
   },
   error: false,
   location: __filename
};

async function getSaldo(number) {
   try {
const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      // Dapatkan konten file account.json
      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      const jsonData = JSON.parse(decodedContent);

      // Cari saldo berdasarkan nomor
      let saldo = null;
      for (const key in jsonData) {
         if (jsonData.hasOwnProperty(key)) {
            const userInfo = jsonData[key];
            const userInfoNumber = key.split('°')[2]; // Ambil nomor dari key

            if (userInfoNumber === number) {
               saldo = userInfo.saldo;
               break;
            }
         }
      }

      return saldo;
   } catch (error) {
      console.error('Failed to get saldo:', error.message);
      throw error;
   }
}
