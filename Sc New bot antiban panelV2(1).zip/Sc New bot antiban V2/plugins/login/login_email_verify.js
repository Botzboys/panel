const axios = require('axios');

exports.run = {
   async: async (m, {
      client,
      body,
      users, 
      Func 
   }) => {
      try {
         let number = (m.sender).split('@')[0];
         if (users.login === true && !m.isGroup && body && body.match(/\d{4}-\d{3}-\d{4}/)) {
            if (users.jid == m.sender && users.code != body.trim()) return client.reply(m.chat, '*🚩 Your verification code is wrong.*', m);
            // Ubah status menjadi true pada account.json
            await changeStatusToTrue(users.username);

            // Update nomor pada account.json
            await updateNumberByUsername(users.username, number);

            // Kirim pesan ke pengguna
            client.reply(m.chat, Func.texted('bold', `✅ Your account has been successfully login.`), m).then(() => {
               users.code = '';
               users.login = false;
               users.password = '';
               users.username = '';
               users.email = '';
            });
         }
      } catch (e) {
         console.log(e);
      }
   },
   error: false,
   private: true,
   cache: true,
   location: __filename
};

async function changeStatusToTrue(username) {
   try {
   const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      // Dapatkan konten file account.json
      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      let jsonData = JSON.parse(decodedContent);

      // Ubah status menjadi true jika username ditemukan
      let found = false;
      for (const key in jsonData) {
         if (jsonData.hasOwnProperty(key)) {
            const userInfo = jsonData[key];
            const userInfoUsername = key.split('°')[1]; // Ambil username dari key

            if (userInfoUsername === username) {
               userInfo.status = true;
               found = true;
               break;
            }
         }
      }

      // Jika username tidak ditemukan
      if (!found) {
         throw new Error(`Username ${username} not found in account.json`);
      }

      // Update konten file account.json
      const updatedContent = JSON.stringify(jsonData, null, 2);
      const encodedContent = Buffer.from(updatedContent).toString('base64');

      await axios.put(apiUrl, {
         message: 'Change user status to true',
         content: encodedContent,
         sha: response.data.sha,
      }, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });
   } catch (error) {
      console.error('Failed to change user status to true:', error.message);
      throw error;
   }
}

async function updateNumberByUsername(username, newNumber) {
   try {
   const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      // Dapatkan konten file account.json
      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      let jsonData = JSON.parse(decodedContent);

      // Ubah nomor pengguna
      const oldKey = Object.keys(jsonData).find(key => key.toLowerCase().split('°')[1] === username.toLowerCase());
      if (oldKey) {
         const newKey = oldKey.replace(/(?<=°)[^°]+$/, newNumber); // Ganti nomor di key
         jsonData[newKey] = jsonData[oldKey]; // Salin data
         delete jsonData[oldKey]; // Hapus data lama

         // Encode dan simpan perubahan pada account.json
         const updatedContent = JSON.stringify(jsonData, null, 2);
         const encodedContent = Buffer.from(updatedContent).toString('base64');

         await axios.put(apiUrl, {
            message: `Update number for ${username}`,
            content: encodedContent,
            sha: response.data.sha,
         }, {
            headers: {
               Authorization: `Bearer ${token}`,
            },
         });
      }
   } catch (error) {
      console.error('Failed to update number by username:', error.message);
      throw error;
   }
}

