const axios = require('axios');

exports.run = {
   async: async (m, {
      client,
      body,
      users, 
      Func 
   }) => {
      try {
         let number = (m.sender).split('@')[0];
         if (users.signup === true && !m.isGroup && body && body.match(/\d{4}-\d{3}-\d{4}/) && !users.verified) {
            if (users.jid == m.sender && users.code != body.trim()) return client.reply(m.chat, '*🚩 Your verification code is wrong.*', m);
            // Ubah status menjadi true pada account.json
            await changeStatusToTrue(number);

            // Kirim pesan ke pengguna
            client.reply(m.chat, Func.texted('bold', `✅ Your account has been successfully verified.`), m).then(() => {
               users.code = '';
               users.signup = false;
               users.verify = true;
               users.password = '';
               users.username = '';
               users.email = '';
            });
         }
      } catch (e) {
         console.log(e);
      }
   },
   error: false,
   private: true,
   cache: true,
   location: __filename
};

async function changeStatusToTrue(number) {
   try {
   const gh = process.env.USERNAME_GH;
      const apiUrl = `https://api.github.com/repos/${gh}/ord-signup/contents/account.json`;
      const token = process.env.TOKEN_GH;

      // Dapatkan konten file account.json
      const response = await axios.get(apiUrl, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });

      const content = response.data.content;
      const decodedContent = Buffer.from(content, 'base64').toString('utf-8');
      let jsonData = JSON.parse(decodedContent);

      // Ubah status menjadi true jika number ditemukan
      for (const key in jsonData) {
         if (jsonData.hasOwnProperty(key)) {
            const userInfo = jsonData[key];
            const userInfoNumber = key.split('°')[2]; // Ambil number dari key

            if (userInfoNumber === number) {
               userInfo.status = true;
               break;
            }
         }
      }

      // Update konten file account.json
      const updatedContent = JSON.stringify(jsonData, null, 2);
      const encodedContent = Buffer.from(updatedContent).toString('base64');

      await axios.put(apiUrl, {
         message: 'Change user status to true',
         content: encodedContent,
         sha: response.data.sha,
      }, {
         headers: {
            Authorization: `Bearer ${token}`,
         },
      });
   } catch (error) {
      console.error('Failed to change user status to true:', error.message);
      throw error;
   }
}
