exports.run = {
   usage: ['cancel'],
   async: async (m, {
      client,
      Func, 
      users, 
      command, 
      isPrefix
   }) => {
      try {
         if (users.login_password === true || users.login_username === true || users.stat_username === true || users.stat_email === true || users.stat_password === true) {
         users.stat_email = false;
         users.stat_password = false;
         users.stat_username = false;
         users.login_username = false; 
         users.login_password = false;
         users.email = '';
         users.password = '';
         users.username = '';
         client.reply(m.chat, '🚩 Registrasi berhasil dimatikan', m)
      }
      } catch (e) {
         console.log(e);
         client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   location: __filename
}