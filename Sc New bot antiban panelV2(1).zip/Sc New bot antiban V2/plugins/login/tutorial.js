exports.run = {
   usage: ['tutorial'],
   category: 'informasi',
   async: async (m, {
      client,
      Func, 
      users
   }) => {
      try {
         users.tutorial_opt = true;
         client.reply(m.chat, `*🔰  T U T O R I A L*

1 - Cara Top Up Game
2 - Cara Isi Pulsa
3 - Cara Top Up Kuota
4 - Cara Top Up Mobile Legends

Kirim pesan 1 - 4, Sesuai dengan pilihan kamu`, m)
      } catch (e) {
         return console.log(e)
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   location: __filename
}