exports.run = {
   usage: ['setprofile'],
   use: 'name', 
   category: 'owner',
   async: async (m, {
      client,
      Func, 
      text, 
      command, 
      isPrefix
   }) => {
      try {
         // Your Code
         if (!text) return client.reply(m.chat, Func.example(isPrefix, command, 'YanaMiku-BOTz'), m);
         if (text.length > 25) return client.reply(m.chat, '🚩 Max name 25 Character', m);
         await client.updateProfileName(text);
         client.reply(m.chat, '*✅ Berhasil mengganti nama Profile Bot*', m);
      } catch (e) {
         console.error(e);
         client.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false,
   owner: true, 
   location: __filename
};